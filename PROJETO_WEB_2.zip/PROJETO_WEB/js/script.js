const USUARIOS_ADMIN = {
    arthur: "arthur123",
    fabricio: "fabricio123",
    blajanik: "blajanik123"
};

const TOTAL_MESAS = 12;
const HORARIOS_VALIDOS = ["11:30", "12:30", "13:30", "19:00", "20:00", "21:00"];

function obterReservas() {
    try {
        return JSON.parse(localStorage.getItem("reservasChurrasco")) || [];
    } catch {
        return [];
    }
}

function salvarReservas(lista) {
    localStorage.setItem("reservasChurrasco", JSON.stringify(lista));
}

function restauranteFechado() {
    return (localStorage.getItem("statusCasa") || "ABERTO PARA RESERVAS") === "FECHADO";
}

function mostrarBanner(elemento, mensagem, tipo = "") {
    if (!elemento) return;
    elemento.textContent = mensagem;
    elemento.className = "banner-aviso " + tipo;
    elemento.style.display = "block";
}

function formatarMoeda(valor) {
    return Number(valor || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

function dataHojeISO() {
    const agora = new Date();
    const ano = agora.getFullYear();
    const mes = String(agora.getMonth() + 1).padStart(2, "0");
    const dia = String(agora.getDate()).padStart(2, "0");
    return `${ano}-${mes}-${dia}`;
}

function validarReserva(dados, idIgnorado = null) {
    const erros = [];

    if (!dados.nome || dados.nome.trim().length < 3) {
        erros.push("O nome deve ter no mínimo 3 caracteres.");
    }

    if (!dados.telefone || dados.telefone.trim().length < 8) {
        erros.push("Informe um telefone válido.");
    }

    if (dados.email && dados.email.trim()) {
        const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regexEmail.test(dados.email.trim())) {
            erros.push("O e-mail informado não está em formato válido.");
        }
    }

    if (!dados.data) {
        erros.push("A data da reserva é obrigatória.");
    } else if (dados.data < dataHojeISO()) {
        erros.push("Não é possível cadastrar reservas para datas no passado.");
    }

    if (!dados.horario || !HORARIOS_VALIDOS.includes(dados.horario)) {
        erros.push("Selecione um horário válido.");
    }

    const pessoas = Number.parseInt(dados.pessoas, 10);
    if (!Number.isInteger(pessoas) || pessoas < 1 || pessoas > 30) {
        erros.push("O número de pessoas deve estar entre 1 e 30.");
    }

    if (dados.mesa !== undefined && !dados.mesa) {
        erros.push("Selecione uma mesa.");
    }

    if (dados.obs && dados.obs.length > 200) {
        erros.push("As observações não podem ultrapassar 200 caracteres.");
    }

    if (dados.eAniversario && (!dados.nomeAniversariante || !dados.nomeAniversariante.trim())) {
        erros.push("Informe o nome do(a) homenageado(a).");
    }

    if (restauranteFechado() && dados.origem !== "Consulta") {
        erros.push("O salão está fechado para novas reservas no momento.");
    }

    if (dados.mesa) {
        const conflito = obterReservas().some(r =>
            r.id !== idIgnorado &&
            r.mesa === dados.mesa &&
            r.data === dados.data &&
            r.horario === dados.horario &&
            r.status !== "Cancelado"
        );

        if (conflito) {
            erros.push("Já existe uma reserva ativa para essa mesa nesse dia e horário.");
        }
    }

    return erros;
}

function configurarAcessoAdmin() {
    const paginaAdmin = document.body.dataset.admin === "true";

    document.querySelectorAll(".nav-admin").forEach(link => {
        link.addEventListener("click", e => {
            if (!verificarAcessoAdmin()) e.preventDefault();
        });
    });

    if (paginaAdmin && !verificarAcessoAdmin()) {
        const caminho = "../index.html";
        window.location.href = caminho;
        return false;
    }

    return true;
}

function verificarAcessoAdmin() {
    if (sessionStorage.getItem("adminLogado")) return true;

    const usuario = prompt("Usuário Administrador (arthur, fabricio ou blajanik):");
    if (!usuario) return false;

    const usuarioFormatado = usuario.trim().toLowerCase();

    if (!USUARIOS_ADMIN[usuarioFormatado]) {
        alert("Usuário não encontrado!");
        return false;
    }

    const senha = prompt(`Senha para o usuário ${usuarioFormatado}:`);
    if (senha !== USUARIOS_ADMIN[usuarioFormatado]) {
        alert("Senha incorreta!");
        return false;
    }

    sessionStorage.setItem("adminLogado", usuarioFormatado);
    return true;
}

function inicializarCamposPublicos() {
    const dataReserva = document.getElementById("dataReserva");
    if (dataReserva) dataReserva.min = dataHojeISO();

    const pessoasReserva = document.getElementById("pessoasReserva");
    const btnMais = document.getElementById("btnMais");
    const btnMenos = document.getElementById("btnMenos");

    if (pessoasReserva && btnMais && btnMenos) {
        btnMais.addEventListener("click", () => {
            pessoasReserva.value = Math.min(30, Number(pessoasReserva.value || 1) + 1);
        });

        btnMenos.addEventListener("click", () => {
            pessoasReserva.value = Math.max(1, Number(pessoasReserva.value || 1) - 1);
        });
    }

    const ocasiao = document.getElementById("ocasiaoEspecial");
    const aniversariante = document.getElementById("campoAniversariante");
    if (ocasiao && aniversariante) {
        const atualizar = () => {
            aniversariante.style.display = ocasiao.checked ? "block" : "none";
        };
        ocasiao.addEventListener("change", atualizar);
        atualizar();
    }
}

function inicializarReservaPublica() {
    const form = document.getElementById("reservaForm");
    if (!form) return;

    form.addEventListener("submit", e => {
        e.preventDefault();

        const resposta = document.getElementById("formResposta");

        const dados = {
            nome: document.getElementById("nome")?.value || "",
            telefone: document.getElementById("telefone")?.value || "",
            email: "",
            mesa: "",
            data: document.getElementById("dataReserva")?.value || "",
            horario: document.getElementById("horarioReserva")?.value || "",
            pessoas: document.getElementById("pessoasReserva")?.value || 1,
            eAniversario: document.getElementById("ocasiaoEspecial")?.checked || false,
            nomeAniversariante: document.getElementById("nomeAniversariante")?.value || "",
            obs: document.getElementById("observacoes")?.value || "",
            origem: "Online"
        };

        const erros = validarReserva(dados);

        if (erros.length) {
            mostrarBanner(resposta, erros.join(" "), "erro");
            return;
        }

        const novaReserva = {
            id: Date.now(),
            nome: dados.nome.trim(),
            telefone: dados.telefone.trim(),
            email: "",
            mesa: "",
            data: dados.data,
            horario: dados.horario,
            dataHora: `${dados.data} - ${dados.horario}`,
            pessoas: Number(dados.pessoas),
            eAniversario: dados.eAniversario,
            obs: dados.eAniversario
                ? `Aniversário (${dados.nomeAniversariante.trim()})`
                : (dados.obs.trim() || "Nenhuma"),
            status: "Pendente",
            origem: "Online"
        };

        const reservas = obterReservas();
        reservas.push(novaReserva);
        salvarReservas(reservas);

        mostrarBanner(
            resposta,
            `Obrigado, ${novaReserva.nome}! Sua reserva para ${novaReserva.data} foi enviada. Entraremos em contato para confirmar.`,
            "sucesso"
        );

        form.reset();
        const pessoas = document.getElementById("pessoasReserva");
        if (pessoas) pessoas.value = 2;
    });
}

function inicializarContato() {
    const form = document.getElementById("contatoDiretoForm");
    if (!form) return;

    form.addEventListener("submit", e => {
        e.preventDefault();
        const resposta = document.getElementById("contatoResposta");
        const nome = document.getElementById("nomeMensagem")?.value.trim();
        const contato = document.getElementById("emailMensagem")?.value.trim();
        const mensagem = document.getElementById("textoMensagem")?.value.trim();

        if (!nome || !contato || !mensagem) {
            mostrarBanner(resposta, "Preencha todos os campos obrigatórios.", "erro");
            return;
        }

        mostrarBanner(resposta, `Mensagem recebida, ${nome}! Entraremos em contato pelo endereço informado.`, "sucesso");
        form.reset();
    });

    const formCompleto = document.getElementById("contatoForm");
    if (!formCompleto) return;

    const tipo = document.getElementById("tipoAtendimento");
    const camposReserva = document.getElementById("camposReserva");

    const alternarTipo = () => {
        if (!tipo || !camposReserva) return;
        camposReserva.style.display = tipo.value === "reserva" ? "block" : "none";
    };

    if (tipo) {
        tipo.addEventListener("change", alternarTipo);
        alternarTipo();
    }

    formCompleto.addEventListener("submit", e => {
        e.preventDefault();

        const resposta = document.getElementById("formResposta");
        const nome = document.getElementById("nome")?.value.trim();
        const telefone = document.getElementById("telefone")?.value.trim();

        if (!nome || !telefone) {
            mostrarBanner(resposta, "Preencha nome e telefone.", "erro");
            return;
        }

        if (tipo?.value === "reserva") {
            const dados = {
                nome,
                telefone,
                email: "",
                mesa: "",
                data: document.getElementById("dataReserva")?.value || "",
                horario: document.getElementById("horarioReserva")?.value || "",
                pessoas: document.getElementById("pessoasReserva")?.value || 1,
                eAniversario: document.getElementById("ocasiaoEspecial")?.checked || false,
                nomeAniversariante: document.getElementById("nomeAniversariante")?.value || "",
                obs: document.getElementById("mensagem")?.value || "",
                origem: "Contato"
            };

            const erros = validarReserva(dados);
            if (erros.length) {
                mostrarBanner(resposta, erros.join(" "), "erro");
                return;
            }

            const reservas = obterReservas();
            reservas.push({
                id: Date.now(),
                nome: dados.nome,
                telefone: dados.telefone,
                email: "",
                mesa: "",
                data: dados.data,
                horario: dados.horario,
                dataHora: `${dados.data} - ${dados.horario}`,
                pessoas: Number(dados.pessoas),
                eAniversario: dados.eAniversario,
                obs: dados.eAniversario
                    ? `Aniversário (${dados.nomeAniversariante.trim()})`
                    : (dados.obs.trim() || "Nenhuma"),
                status: "Pendente",
                origem: "Contato"
            });
            salvarReservas(reservas);
            mostrarBanner(resposta, `Solicitação de ${nome} registrada com sucesso.`, "sucesso");
        } else {
            mostrarBanner(resposta, `Mensagem de ${nome} recebida com sucesso.`, "sucesso");
        }

        formCompleto.reset();
        alternarTipo();
    });
}

function preencherMesas(selectId) {
    const select = document.getElementById(selectId);
    if (!select) return;

    if (select.options.length > 1) return;

    for (let i = 1; i <= TOTAL_MESAS; i++) {
        const option = document.createElement("option");
        option.value = `Mesa ${i}`;
        option.textContent = `Mesa ${i}`;
        select.appendChild(option);
    }
}

function inicializarConsulta() {
    const form = document.getElementById("cadastroForm");
    if (!form) return;

    preencherMesas("cMesa");
    preencherMesas("eMesa");

    const cData = document.getElementById("cData");
    if (cData) cData.min = dataHojeISO();

    const checkAniversario = document.getElementById("cAniversario");
    const campoAniversariante = document.getElementById("campoAniversarianteAdmin");
    if (checkAniversario && campoAniversariante) {
        checkAniversario.addEventListener("change", () => {
            campoAniversariante.style.display = checkAniversario.checked ? "block" : "none";
        });
    }

    const obs = document.getElementById("cObs");
    const contadorObs = document.getElementById("contadorObs");
    if (obs && contadorObs) {
        obs.addEventListener("input", () => {
            contadorObs.textContent = `${obs.value.length}/200 caracteres`;
        });
    }

    function carregarStatusCasa() {
        const status = localStorage.getItem("statusCasa") || "ABERTO PARA RESERVAS";
        const badge = document.getElementById("statusCasaBadge");
        const aviso = document.getElementById("avisoFechado");

        if (badge) {
            badge.textContent = status;
            badge.className =
                "status-casa " +
                (status.includes("ABERTO") ? "aberto" : status.includes("LOTADO") ? "lotado" : "fechado");
        }

        if (aviso) aviso.style.display = status === "FECHADO" ? "block" : "none";
    }

    window.alterarStatusCasa = function (novoStatus) {
        localStorage.setItem("statusCasa", novoStatus);
        carregarStatusCasa();
    };

    window.atualizarPainel = function () {
        const reservas = obterReservas();
        const valorInput = document.getElementById("valorRodizio");
        const preco = Math.max(0, Number.parseFloat(String(valorInput?.value || "89.90").replace(",", ".")) || 0);

        const confirmadas = reservas.filter(r => r.status === "Confirmado");
        const pessoas = confirmadas.reduce((soma, r) => soma + (Number(r.pessoas) || 0), 0);

        const set = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.textContent = value;
        };

        set("qtdTotal", reservas.length);
        set("qtdConfirmadas", confirmadas.length);
        set("qtdPessoas", pessoas);
        set("faturamentoEstimado", formatarMoeda(pessoas * preco));

        const lista = document.getElementById("listaAtencaoEspecial");
        if (lista) {
            lista.innerHTML = "";
            const especiais = reservas.filter(r => r.eAniversario || (r.obs && r.obs !== "Nenhuma"));
            if (!especiais.length) {
                lista.innerHTML = "<li>Nenhum evento especial registrado.</li>";
            } else {
                especiais.forEach(r => {
                    const li = document.createElement("li");
                    li.textContent = `${r.nome} (${r.data || ""} ${r.horario || ""}): ${r.obs}`;
                    lista.appendChild(li);
                });
            }
        }
    };

    form.addEventListener("submit", e => {
        e.preventDefault();

        const dados = {
            nome: document.getElementById("cNome")?.value || "",
            telefone: document.getElementById("cTelefone")?.value || "",
            email: document.getElementById("cEmail")?.value || "",
            mesa: document.getElementById("cMesa")?.value || "",
            data: document.getElementById("cData")?.value || "",
            horario: document.getElementById("cHorario")?.value || "",
            pessoas: document.getElementById("cPessoas")?.value || 1,
            eAniversario: document.getElementById("cAniversario")?.checked || false,
            nomeAniversariante: document.getElementById("cNomeAniversariante")?.value || "",
            obs: document.getElementById("cObs")?.value || "",
            origem: "Consulta"
        };

        const resposta = document.getElementById("cadastroResposta");
        const erros = validarReserva(dados);

        if (erros.length) {
            mostrarBanner(resposta, erros.join(" "), "erro");
            return;
        }

        const novaReserva = {
            id: Date.now(),
            nome: dados.nome.trim(),
            telefone: dados.telefone.trim(),
            email: dados.email.trim(),
            mesa: dados.mesa,
            data: dados.data,
            horario: dados.horario,
            dataHora: `${dados.data} - ${dados.horario}`,
            pessoas: Number(dados.pessoas),
            eAniversario: dados.eAniversario,
            obs: dados.eAniversario
                ? `Aniversário (${dados.nomeAniversariante.trim()})`
                : (dados.obs.trim() || "Nenhuma"),
            status: document.getElementById("cStatusInicial")?.value || "Pendente",
            origem: "Balcão"
        };

        salvarReservas([...obterReservas(), novaReserva]);
        mostrarBanner(resposta, `Reserva de ${novaReserva.nome} cadastrada com sucesso na ${novaReserva.mesa}!`, "sucesso");
        form.reset();
        if (contadorObs) contadorObs.textContent = "0/200 caracteres";
        if (campoAniversariante) campoAniversariante.style.display = "none";
        window.atualizarPainel();
        renderConsulta();
    });

    const busca = document.getElementById("buscaTexto");
    const filtroStatus = document.getElementById("filtroStatus");
    const filtroData = document.getElementById("filtroData");
    const tabela = document.getElementById("tabelaConsultaBody");
    const contador = document.getElementById("contadorResultados");
    let idParaExcluir = null;

    function renderConsulta() {
        if (!tabela) return;

        const termo = (busca?.value || "").trim().toLowerCase();
        const status = filtroStatus?.value || "todos";
        const data = filtroData?.value || "";

        const resultado = obterReservas().filter(r => {
            const bateTexto = !termo ||
                String(r.nome || "").toLowerCase().includes(termo) ||
                String(r.telefone || "").includes(termo);
            return bateTexto &&
                (status === "todos" || r.status === status) &&
                (!data || r.data === data);
        });

        tabela.innerHTML = "";

        if (!resultado.length) {
            tabela.innerHTML = '<tr class="linha-vazia"><td colspan="7">Nenhuma reserva encontrada.</td></tr>';
            if (contador) contador.textContent = "0 reservas encontradas.";
            return;
        }

        if (contador) contador.textContent = `${resultado.length} reserva(s) encontrada(s).`;

        resultado.forEach(r => {
            const tr = document.createElement("tr");

            if (idParaExcluir === r.id) {
                tr.innerHTML = `
                    <td colspan="6">Confirma a exclusão da reserva de <strong>${escapeHTML(r.nome)}</strong>?</td>
                    <td>
                        <button class="btn-acao recusar" data-acao="confirmar-exclusao" data-id="${r.id}">Sim, excluir</button>
                        <button class="btn-acao" data-acao="cancelar-exclusao">Cancelar</button>
                    </td>`;
            } else {
                tr.innerHTML = `
                    <td><strong>${escapeHTML(r.nome)}</strong><br><small>${escapeHTML(r.telefone)}</small></td>
                    <td>${escapeHTML(r.mesa || "-")}</td>
                    <td>${escapeHTML(r.data || "")} - ${escapeHTML(r.horario || "")}</td>
                    <td>${Number(r.pessoas) || 0}</td>
                    <td>${escapeHTML(r.obs || "Nenhuma")}</td>
                    <td><span class="status-badge ${String(r.status).toLowerCase()}">${escapeHTML(r.status)}</span></td>
                    <td>
                        <button class="btn-acao aprovar" data-acao="editar" data-id="${r.id}">Editar</button>
                        <button class="btn-acao recusar" data-acao="excluir" data-id="${r.id}">Excluir</button>
                    </td>`;
            }

            tabela.appendChild(tr);
        });
    }

    if (tabela) {
        tabela.addEventListener("click", e => {
            const botao = e.target.closest("button");
            if (!botao) return;

            const acao = botao.dataset.acao;
            const id = Number.parseInt(botao.dataset.id, 10);

            if (acao === "excluir") {
                idParaExcluir = id;
                renderConsulta();
            } else if (acao === "cancelar-exclusao") {
                idParaExcluir = null;
                renderConsulta();
            } else if (acao === "confirmar-exclusao") {
                salvarReservas(obterReservas().filter(r => r.id !== id));
                idParaExcluir = null;
                renderConsulta();
                window.atualizarPainel();
            } else if (acao === "editar") {
                abrirEdicao(id);
            }
        });
    }

    [busca, filtroStatus, filtroData].forEach(el => {
        if (el) {
            el.addEventListener(el.tagName === "INPUT" ? "input" : "change", renderConsulta);
        }
    });

    const limpar = document.getElementById("btnLimparFiltros");
    if (limpar) {
        limpar.addEventListener("click", () => {
            if (busca) busca.value = "";
            if (filtroStatus) filtroStatus.value = "todos";
            if (filtroData) filtroData.value = "";
            renderConsulta();
        });
    }

    const painelEdicao = document.getElementById("painelEdicao");
    const editarForm = document.getElementById("editarForm");

    function abrirEdicao(id) {
        const r = obterReservas().find(item => item.id === id);
        if (!r || !painelEdicao) return;

        document.getElementById("eId").value = r.id;
        document.getElementById("eNome").value = r.nome || "";
        document.getElementById("eTelefone").value = r.telefone || "";
        document.getElementById("eData").value = r.data || "";
        document.getElementById("eHorario").value = r.horario || HORARIOS_VALIDOS[0];
        document.getElementById("ePessoas").value = r.pessoas || 1;
        document.getElementById("eMesa").value = r.mesa || "";
        document.getElementById("eObs").value = r.obs === "Nenhuma" ? "" : (r.obs || "");
        document.getElementById("eStatus").value = r.status || "Pendente";

        painelEdicao.style.display = "block";
        painelEdicao.scrollIntoView({ behavior: "smooth" });
    }

    document.getElementById("btnCancelarEdicao")?.addEventListener("click", () => {
        if (painelEdicao) painelEdicao.style.display = "none";
        editarForm?.reset();
    });

    editarForm?.addEventListener("submit", e => {
        e.preventDefault();

        const id = Number.parseInt(document.getElementById("eId").value, 10);
        const dados = {
            nome: document.getElementById("eNome").value,
            telefone: document.getElementById("eTelefone").value,
            data: document.getElementById("eData").value,
            horario: document.getElementById("eHorario").value,
            pessoas: document.getElementById("ePessoas").value,
            mesa: document.getElementById("eMesa").value,
            obs: document.getElementById("eObs").value,
            eAniversario: false,
            nomeAniversariante: "",
            origem: "Consulta"
        };

        const resposta = document.getElementById("edicaoResposta");
        const erros = validarReserva(dados, id);

        if (erros.length) {
            mostrarBanner(resposta, erros.join(" "), "erro");
            return;
        }

        const status = document.getElementById("eStatus").value;

        salvarReservas(obterReservas().map(r => r.id === id ? {
            ...r,
            nome: dados.nome.trim(),
            telefone: dados.telefone.trim(),
            data: dados.data,
            horario: dados.horario,
            mesa: dados.mesa,
            dataHora: `${dados.data} - ${dados.horario}`,
            pessoas: Number(dados.pessoas),
            obs: dados.obs.trim() || "Nenhuma",
            status
        } : r));

        mostrarBanner(resposta, "Reserva atualizada com sucesso!", "sucesso");
        renderConsulta();
        window.atualizarPainel();

        setTimeout(() => {
            if (painelEdicao) painelEdicao.style.display = "none";
        }, 1000);
    });

    carregarStatusCasa();
    window.atualizarPainel();
    renderConsulta();
}

function escapeHTML(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[char]));
}

function inicializarRelatorios() {
    const inicio = document.getElementById("relatorioInicio");
    const fim = document.getElementById("relatorioFim");
    const status = document.getElementById("relatorioStatus");
    const botao = document.getElementById("btnGerarRelatorio");

    if (!inicio || !fim || !status || !botao) return;

    const hoje = dataHojeISO();
    inicio.value = hoje;
    fim.value = hoje;

    function gerar() {
        const reservas = obterReservas().filter(r => {
            const dentroInicio = !inicio.value || (r.data || "") >= inicio.value;
            const dentroFim = !fim.value || (r.data || "") <= fim.value;
            const dentroStatus = status.value === "todos" || r.status === status.value;
            return dentroInicio && dentroFim && dentroStatus;
        });

        const pessoas = reservas.reduce((soma, r) => soma + (Number(r.pessoas) || 0), 0);
        const confirmadas = reservas.filter(r => r.status === "Confirmado");
        const pessoasConfirmadas = confirmadas.reduce((soma, r) => soma + (Number(r.pessoas) || 0), 0);

        const preco = Number.parseFloat(localStorage.getItem("valorRodizio")) || 89.90;

        document.getElementById("relTotal").textContent = reservas.length;
        document.getElementById("relPessoas").textContent = pessoas;
        document.getElementById("relConfirmadas").textContent = confirmadas.length;
        document.getElementById("relFaturamento").textContent = formatarMoeda(pessoasConfirmadas * preco);

        const statusBody = document.getElementById("relStatusBody");
        statusBody.innerHTML = "";

        ["Pendente", "Confirmado", "Cancelado"].forEach(nomeStatus => {
            const grupo = reservas.filter(r => r.status === nomeStatus);
            const qtdPessoas = grupo.reduce((soma, r) => soma + (Number(r.pessoas) || 0), 0);
            statusBody.innerHTML += `<tr><td>${nomeStatus}</td><td>${grupo.length}</td><td>${qtdPessoas}</td></tr>`;
        });

        const reservasBody = document.getElementById("relReservasBody");
        reservasBody.innerHTML = "";

        if (!reservas.length) {
            reservasBody.innerHTML = '<tr><td colspan="6">Nenhuma reserva encontrada para os filtros selecionados.</td></tr>';
            return;
        }

        reservas.sort((a, b) => `${a.data}${a.horario}`.localeCompare(`${b.data}${b.horario}`));
        reservas.forEach(r => {
            reservasBody.innerHTML += `
                <tr>
                    <td>${escapeHTML(r.nome)}</td>
                    <td>${escapeHTML(r.data)}</td>
                    <td>${escapeHTML(r.horario)}</td>
                    <td>${escapeHTML(r.mesa || "-")}</td>
                    <td>${Number(r.pessoas) || 0}</td>
                    <td>${escapeHTML(r.status)}</td>
                </tr>`;
        });
    }

    const valorInput = document.getElementById("valorRodizio");
    if (valorInput) {
        valorInput.addEventListener("input", () => {
            localStorage.setItem("valorRodizio", valorInput.value);
            gerar();
        });
    }

    botao.addEventListener("click", gerar);
    gerar();
}

document.addEventListener("DOMContentLoaded", () => {
    if (!configurarAcessoAdmin()) return;

    inicializarCamposPublicos();
    inicializarReservaPublica();
    inicializarContato();
    inicializarConsulta();
    inicializarRelatorios();
});
